import React from 'react'
import './About.css'

import Section from '../../components/Basic/Section'

const About = () => {
  return(
    <>
    <Section title="Sobre Mim">
      Me chamo Juan Guilherme de Oliveira, sou natural de Natal-RN e sou um desenvolvedor web front-end. Atualmente curso bacharelado em tecnologia da informação e pretendo seguir como Engenheiro de Software.
      <br/><br/>
      Sou altamente curioso e motivado a conhecer cada vez mais sobre novas técnicas e tecnologias. Também sou aspirante em design e UX e UI.
    </Section>

    <Section title="Minhas Habilidades">
      Tenho um sólido conhecimento nas principais tecnologias da web como HTML e CSS e também no ecossistema Javascript.
      <br/><br/>
      
    </Section>
    </>
  )
}

export default About