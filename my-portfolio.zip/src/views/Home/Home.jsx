import React from 'react'
import './Home.css'

import Section from '../../components/Basic/Section'

const Home = () => {
  return(
      <>
      <Section title="Pagina Inicial">
        Texto da página inicial...
        <br/><br/>
      </Section>
      </>
  )
}

export default Home