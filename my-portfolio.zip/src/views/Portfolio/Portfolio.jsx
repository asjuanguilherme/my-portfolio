import React from 'react'
import './Portfolio.css'

import Section from '../../components/Basic/Section'
import Showcase from '../../components/layout/Showcase'
import ProjectTemplate from '../../components/Basic/ProjectTemplate'

import DianaPrint from '../Portfolio/prints/diana.jpg'

const Portfolio = () => {
  return(
<>
    <Section title="Portfólio">
      Alguns dos projetos realizados por mim.
      <br/><br/>
      <Showcase>
        <ProjectTemplate 
          name="Diana - Loja Virtual"
          description="loja virtual e sistema feito para loja diana"
          photo={ DianaPrint }
        />
        <ProjectTemplate/>
        <ProjectTemplate/>
        <ProjectTemplate/>
        <ProjectTemplate/>
        <ProjectTemplate/>
        <ProjectTemplate/>
        <ProjectTemplate/>
        <ProjectTemplate/>
      </Showcase>
    </Section>
    </>
  )
}

export default Portfolio